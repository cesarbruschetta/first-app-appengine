#!/usr/bin/env python


import cgi;
import wsgiref.handlers

from google.appengine.ext import webapp
from google.appengine.ext.webapp.util \
    import run_wsgi_app

from ddt import DDTHandler


# *** Symbolic Constants ***

BASE = ord('0')


def mainForm():
  return """
    <html>
      <head>
        <title>
          Strong(ish) Password Generator
        </title>
      </head>
      <body>
        <div align="center">
          <h1>Strong(ish) Password Generator</h1>
          <form
            method="POST"
            name="baseWordCapture"
            action="/">
              <p>Base word (6 chars minimum):</p>
              <input type="text" name="baseWord"
                cols="24" /> <br />
              <input type="submit" />
              <input type="reset" />
              <p>Password:</p>
              <p>n/a</p>
          </form>
          <hr />
          <p>&#169; 2008 Eugene Ciurana</p>
        </div>
      </body>
    </html>
  """


class PasswordGenerator(DDTHandler):

  def __process(self, aWord):
    password = ""
    if (len(aWord) >= 6):
      for i in range(len(aWord)):
        if i in [1, 5, 8, 13, 21]:
          password += chr(BASE+(ord(aWord[i])+i)%10)
        else:
          password += aWord[i]

    return password

  def get(self):
    self.viewRequest()
    self.response.out.write(mainForm())

  def post(self):
    self.viewRequest()
    output   = self.response.out
    baseWord = cgi.escape(
        self.request.get('baseWord'))
    password = self.__process(baseWord)

    output.write(mainForm().replace(
        "n/a", password))


def main():
  application = webapp.WSGIApplication(
      [ ('/', PasswordGenerator) ], debug=True)

  run_wsgi_app(application)


if __name__ == '__main__':
  main()
  
