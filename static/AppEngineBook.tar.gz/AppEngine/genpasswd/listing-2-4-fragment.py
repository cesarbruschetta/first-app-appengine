class MainPage(webapp.RequestHandler):

  def get(self):
    self.response.out.write(mainForm())


class UserRequestHandler(webapp.RequestHandler):

  def __process(self, aWord):
    password = ""
    if (len(aWord) > 6):
      for i in range(len(aWord)):
        if i in [1, 5, 8, 13, 21]:
          password += chr(BASE+(ord(aWord[i])+i)%10)
        else:
          password += aWord[i]

    return password

  def post(self):
    output   = self.response.out
    baseWord = cgi.escape(
        self.request.get('baseWord'))
    password = self.__process(baseWord)

    output.write(mainForm().replace(
        "n/a", password))


