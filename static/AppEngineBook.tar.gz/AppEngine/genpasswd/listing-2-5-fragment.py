def main():
  application = webapp.WSGIApplication(
      [ 
        ('/', MainPage),
        ('/passwordGenRequest', UserRequestHandler)
      ], debug=True)

  run_wsgi_app(application)

