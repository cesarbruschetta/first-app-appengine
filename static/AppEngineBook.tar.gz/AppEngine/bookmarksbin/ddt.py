#!/usr/bin/python


import cgi
import wsgiref.handlers

from google.appengine.ext import webapp

class DDTHandler(webapp.RequestHandler):
  
  def __startDisplay(self):
    self.response.out.write("<!--\n")


  def __endDisplay(self):
    self.response.out.write("-->\n")


  def __showDictionaryItems(self, dictionary, title):
    if (len(dictionary) > 0):
      request = self.request
      out     = self.response.out
      out.write("\n"+title+":\n")
      for key, value in dictionary.iteritems():
        out.write(key+" = "+value+"\n")
  

  def __showRequestMembers(self):
    request = self.request
    out     = self.response.out

    out.write(request.url+"\n")
    out.write("Query = "+request.query_string+"\n")
    out.write("Remote = "+request.remote_addr+"\n")
    out.write("Path = "+request.path+"\n\n")
    out.write("Request payload:\n")
    if (len(request.arguments()) > 0):
      for argument in request.arguments():
        value = cgi.escape(request.get(argument))
        out.write(argument+" = "+value+"\n")
    else:
      out.write("Empty\n")
    self.__showDictionaryItems(
        request.headers, "Headers")
    self.__showDictionaryItems(
        request.cookies, "Cookies")


  def viewRequest(self):
    self.__startDisplay()
    self.__showRequestMembers()
    self.__endDisplay()

  def view(self, aString):
    self.__startDisplay()
    self.response.out.write(aString+"\n")
    self.__endDisplay()

