


from google.appengine.ext import db

from bookmark import Bookmark
from tag import Tag


class BookmarkTag(db.Model):
  bookmark = db.ReferenceProperty(Bookmark,
      collection_name = 'tagsbookmarks')
  tag = db.ReferenceProperty(Tag,
      collection_name = 'bookmarkstags')


  @classmethod
  def taggedCacheKey(self):
    return None
