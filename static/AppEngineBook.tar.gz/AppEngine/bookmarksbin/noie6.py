


from apptools import AppHandler


class NoIE6Pages(AppHandler):

  # *** Public methods ***

  def get(self):
    if self.hasValidUser():
      self.renderPage('noie6.html', None)
  
