


import apptools

from google.appengine.api import memcache
from google.appengine.ext import db

from owner import Owner


class Tag(db.Model):
  name = db.StringProperty()
  owner = db.ReferenceProperty(Owner,
      collection_name = 'tags')

  
  def delete(self):
    name = self.name
    super(Tag, self).delete()

    memcache.delete(Tag.cacheKeyFor(name))


  def put(self):
    super(Tag, self).put()

    memcache.delete(Tag.cacheKeyFor(self.name))
    memcache.add(
        Tag.cacheKeyFor(self.name), self,
        apptools.DAY_AS_SECONDS)
    

  @classmethod
  def cacheKeyFor(self, tagName):
    cacheKey  = str(Owner.getCurrent().key().id_or_name())
    cacheKey += ".Tag.name="+tagName 

    return cacheKey


  @classmethod
  def getTagFor(self, aName):
    cacheKey = Tag.cacheKeyFor(aName)
    tag = memcache.get(cacheKey)

    if tag is None:
      tag = self.all().filter('owner = ',
        Owner.getCurrent()).filter('name = ', aName).get()
      memcache.add(
          cacheKey, tag, apptools.DAY_AS_SECONDS)

    return tag


  @classmethod
  def getAllNames(self):
    tags = Owner.getCurrent().tags
    tagNames = ['unclassified']

    for tag in tags:
      tagNames.append(tag.name)

    return sorted(tagNames)

