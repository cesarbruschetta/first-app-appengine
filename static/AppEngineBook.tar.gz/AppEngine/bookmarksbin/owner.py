


import apptools

from google.appengine.api import memcache
from google.appengine.api import users
from google.appengine.ext import db


def ownerKey():
  return "User.email="+users.get_current_user().email()


class Owner(db.Model):
  user     = db.UserProperty()
  email    = db.StringProperty()
  nickname = db.StringProperty()
  bOpenNew = db.BooleanProperty()


  def put(self):
    super(Owner, self).put()

    memcache.delete(ownerKey())
    memcache.add(
        ownerKey(), self, apptools.DAY_AS_SECONDS)


  # *** Class methods ***

  @classmethod
  def getCurrent(self):
    owner = memcache.get(ownerKey())

    if owner is None:
      owner = Owner.all().filter('user = ',
          users.get_current_user()).get()
      memcache.add(
          ownerKey(), owner,
          apptools.DAY_AS_SECONDS)

    return owner

  # *** End class methods ***


  @property
  def id_or_name(self):
    return self.key().id_or_name()

