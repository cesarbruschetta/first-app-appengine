#!/usr/bin/env python


import cgi
import logging
import operator
import os
import wsgiref.handlers

import apptools

from datetime import date
from urllib import urlencode
from urlparse import urlsplit

from google.appengine.api import images
from google.appengine.api import mail
from google.appengine.api import memcache
from google.appengine.ext import db
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp.util \
    import run_wsgi_app
from google.appengine.api.urlfetch import fetch

from apptools import AppHandler
from bookmark import Bookmark
from bookmarktag import BookmarkTag
from noie6 import NoIE6Pages
from owner import Owner
from tag import Tag
from tagsmanagement import TagsManagement
from userpreferences import UserPreferences


def commitBookmark(aBookmark, tagsList, theParent):
  aBookmark.put()
  for tag in tagsList:
    BookmarkTag(
        bookmark = aBookmark, tag = tag,
        parent = theParent).put()


def deleteBookmarkAndAssociations(aBookmark, references):
  for reference in references:
    reference.delete()
  aBookmark.delete()


def bookmarkKey(nID):
  key  = str(Owner.getCurrent().key().id_or_name())
  key += ".BookmarksBin.nID="+str(nID)

  return key


class BookmarksBin(AppHandler):
  # *** Private members ***

  def _currentEmailTargetKey(self):
    key  = str(Owner.getCurrent().key().id_or_name())
    key += ".BookmarksBin.emailTarget"

    return key


  def _displayBookmarksPage(self,
      filteredBookmarks = None):
    v = dict(logOffURL = self.getLogOffURL())
    v['tagNames']  = Tag.getAllNames()
    t = self.request.get('tags')
    if t != '' and t != u'unclassified':
      v['currentTag'] = Tag.getTagFor(
          self.request.get('tags')).name
    if filteredBookmarks is None:
      v['bookmarks'] = Bookmark.getAll()
    else:
      v['bookmarks'] = filteredBookmarks
    v['bOpenNew'] = Owner.getCurrent().bOpenNew
    email = memcache.get(self._currentEmailTargetKey())

    if email is not None:
      v['bookmarkEmail'] = email
    else:
      v['bookmarkEmail'] = ""

    self.renderPage('bookmarksbin.html', v)


  def _allBooksForTagKey(self, tagName):
    cacheKey  = str(Owner.getCurrent().id_or_name)
    cacheKey += ".BookmarkTag.for:"+tagName

    return cacheKey


  def _fetchIconFor(self, aLocator):
    components = urlsplit(aLocator)
    iconRef    = components[0]
    iconRef   += "://"+components[1]
    iconRef   += "/favicon.ico"

    icon = None

    try:
      logging.info("Fetching "+iconRef)
      result = fetch(iconRef)
      if 200 == result.status_code:
        icon = result.content
        icon = images.resize(icon, 24, 24)
        icon = images.im_feeling_lucky(icon,
            output_encoding = images.ICO)
    except:
      logging.info("Failed to fetch "+iconRef)

    return icon


  def _addBookmark(self):
    tagNames = self.request.get_all('tags')
    locator  = cgi.escape(self.request.get('locator'))

    bookmark = Bookmark(
       parent = Owner.getCurrent(),
       description = cgi.escape(
           self.request.get('description')),
       favIcon = self._fetchIconFor(locator),
       locator = locator,
       title = None,
       owner = Owner.getCurrent())

    tagsList = list()
    if len(tagNames) < 1:
      tagsList.append(None)
    else:
      for tagName in tagNames:
        tagsList.append(Tag.getTagFor(tagName))

    db.run_in_transaction(
        commitBookmark, bookmark,
        tagsList, Owner.getCurrent())

    memcache.flush_all()


  def _bookmarkKey(self, nID):
    return bookmarkKey(nID)

  def _deleteBookmark(self):
    nID = int(self.request.get('bookmarkID'))
    bookmark = Bookmark.get_by_id(nID, Owner.getCurrent())
    references = BookmarkTag.all().filter(
        'bookmark = ', bookmark).fetch(1000)

    memcache.delete(self._bookmarkKey(nID))
    db.run_in_transaction(
        deleteBookmarkAndAssociations,
        bookmark, references)

    memcache.flush_all()

    return None


  def _filterBookmarksFor(self, tag):
    cacheKey = self._allBooksForTagKey(tag)
    bookmarks = memcache.get(cacheKey)
    
    if bookmarks is None:
      if tag == u'unclassified':
        bookmarks = Bookmark.getAll()
      else:
        bookmarks = [x.bookmark 
            for x in BookmarkTag.all().filter(
              'tag = ', Tag.getTagFor(tag)).fetch(1000)]
        bookmarks.sort(
            key=operator.attrgetter('description'))

      memcache.add(cacheKey, bookmarks,
          7*apptools.DAY_AS_SECONDS)

    return bookmarks


  def _renderEmail(self, fileName, values):
    path = os.path.join(os.path.dirname(__file__),
        fileName)
    return template.render(path, values)


  def _compressURL(self, aLocator):
    ISGD_URI = 'http://is.gd/api.php?longurl='
    l = urlencode({'l': aLocator})

    try:
      result = fetch(ISGD_URI+l[2:])
      if 200 == result.status_code:
        return result.content
      else:
        return aLocator
    except:
      return aLocator


  def _dispatchEmailTo(self, email, nID):
    owner = Owner.getCurrent()
    bookmark = memcache.get(self._bookmarkKey(nID))

    if bookmark is None:
      bookmark = Bookmark.get_by_id(nID, owner)
      memcache.set(self._bookmarkKey(nID), bookmark)

    values = dict(name = owner.nickname,
        locator = self._compressURL(bookmark.locator),
        description = bookmark.description)

    message = mail.EmailMessage(
        sender = owner.email,
        subject = "BookmarksBin shared link")

    message.to = email
    message.body = self._renderEmail(
        "share_bookmark.eml", values)

    message.send()
    logging.info("Email to "+email+" sent")


  def _shareBookmark(self):
    email = cgi.escape(self.request.get('recipient'))
    nID   = int(self.request.get('bookmarkID'))
    memcache.set(self._currentEmailTargetKey(), email)
    self._dispatchEmailTo(email, nID)
    self.renderPage('window_close.html', None)


  def _processAction(self):
    action = self.request.get('action')
    logging.info('action = '+action)

    bookmarks = Bookmark.getAll()

    if action == 'add':
      self._addBookmark()
      bookmarks = Bookmark.getAll()
    elif action == 'view':
      bookmarks = self._filterBookmarksFor(
          self.request.get('tags'))
    elif action == 'del':
      bookmarks = self._deleteBookmark()
    elif action == 'share':
      self._shareBookmark()

    return bookmarks


  # *** Public methods ***

  def get(self):
    if self.hasValidUser():
      if self.isNewUser():
        self.redirect("/userpreferences")
      else:
        self._displayBookmarksPage()


  def post(self):
    if self.hasValidUser():
      if self.isNewUser():
        self.redirect("/userpreferences")
      else:
        bookmarks = self._processAction()
        self._displayBookmarksPage(bookmarks)


class IconServer(AppHandler):
  def get(self):
    nID = int(self.request.get('id'))
    if nID == None:
      nID = -1
    bookmark = memcache.get(
        bookmarkKey(nID))

    if bookmark is None:
      bookmark = Bookmark.get_by_id(nID,
          Owner.getCurrent())
      memcache.set(bookmarkKey(nID), bookmark)

    if bookmark.favIcon:
      self.response.headers['Content-Type'] = \
          'image/ico'
      self.response.out.write(bookmark.favIcon)
    else:
      logging.info("Invalid icon req "+str(nID))
      self.response.out.write("No icon")


def main():
  application = webapp.WSGIApplication([
      ('/', BookmarksBin),
      ('/userpreferences', UserPreferences),
      ('/tagsmanagement', TagsManagement),
      ('/noie6', NoIE6Pages),
      ('/icon', IconServer)],
      debug=True)
  run_wsgi_app(application)


if __name__ == '__main__':
  main()

