


import cgi
import operator

from google.appengine.api import users
from google.appengine.ext import db

from apptools import AppHandler

from bookmarktag import BookmarkTag
from owner import Owner
from tag import Tag


def deleteTagAndAssociations(tag, relationships):
  for relatedBookmark in relationships:
    relatedBookmark.delete()

  tag.delete()


class TagsManagement(AppHandler):
  # *** Symbolic constants ***

  MAX_TAGS = 1000       # App Engine limit


  # *** Private members ***

  def _fetchAllTags(self):
#    query = Tag.gql(
#        "WHERE owner = :owner ORDER BY name ASC",
#        Owner.getCurrent())
#    return query.fetch(TagsManagement.MAX_TAGS)

    return Owner.getCurrent().tags.order('name')


  def _displayTagsManagementPage(self):
    allTags = self._fetchAllTags()
    _v = dict(logOffURL = self.getLogOffURL())
    _v['tagsList'] = allTags
    self.renderPage('tagsmanagement.html', _v)


  def _addNewTag(self, tagName):
    if len(tagName) < 1:
      return

    currentOwner = Owner.getCurrent()
    tags         = currentOwner.tags

    if tagName not in tags:
      tag = Tag(parent = currentOwner, # owner's group
                name   = tagName,
                owner  = currentOwner)
      tag.put()


  def _addTags(self):
    tagText = cgi.escape(self.request.get('tag')).lower()
    tagText = tagText.split(" ")
    for tagName in tagText:
      self._addNewTag(tagName)


  def _deleteTag(self):
    tagName = self.request.get('tag')
    query = db.Query(Tag)
    query.filter(
        "owner = ", Owner.getCurrent()).filter(
        "name = ", tagName)

    results = query.fetch(1)
    if (len(results) > 0):
      tag = results[0]
      relationships = BookmarkTag.all().filter(
          'tag = ', tag).fetch(1000)
      db.run_in_transaction(
        deleteTagAndAssociations, tag, relationships)


  # *** Public methods ****

  def get(self):
    if self.hasValidUser():
      if self.isNewUser():
        self.redirect("/userpreferences")
      else:
        self._displayTagsManagementPage()


  def post(self):
    if self.hasValidUser():
      print "Delete: "+self.request.get('tag')
      action = self.request.get('action')
      if ('add' == action):
        self._addTags()
      elif ('del' == action):
        self._deleteTag()

      self._displayTagsManagementPage()

