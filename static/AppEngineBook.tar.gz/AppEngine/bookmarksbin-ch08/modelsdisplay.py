


import os
import apptools

from google.appengine.api import memcache
from google.appengine.api import users
from google.appengine.api.urlfetch import fetch
from google.appengine.ext import db

from bookmark import Bookmark
from bookmarktag import BookmarkTag
from owner import Owner
from tag import Tag

print 'Content-Type: text/plain'
print ''


#
#def display(anOwner):
#  print "owner = "+anOwner.nickname
#  if (anOwner.is_saved()):
#    print "key = ", anOwner.key().id_or_name()
#  print ""
#  
#
#o0 = Owner(
#    email    = "user@domain.com",
#    nickname = "pr3d4t0r",
#    bOpenNew = False)
#
#o1 = Owner(
#    email    = "user2@domain.com",
#    nickname = "NikkiWade",
#    bOpenNew = False,
#    key_name = "NikkiWade")

# o0.put()
# o1.put()
#display(o0)
#display(o1)

#def queryExample():
#  query = db.GqlQuery(
#      "SELECT * FROM Tag WHERE owner = :1 \
#      ORDER BY name ASC",
#      Owner.getCurrent())
#
#  results = query.fetch(1000)
#  
#  return results
#
#tags = queryExample()
#
#for tag in tags:
#  key = tag.key()
#  print tag.name
#  print tag.owner.nickname
#  print key.app()
#  print key.kind()
#  parent = key.parent()
#  if (key != None):
#    print "parent = ", parent.id_or_name(), parent.kind()
#  if key.has_id_or_name:
#    print key.id_or_name()
#  print "------------------"

#def getAllNames():
#  tags = Owner.getCurrent().tags
#  tagNames = [u'unclassified']
#
#  for tag in tags:
#    tagNames.append(tag.name)
#
#  return sorted(tagNames)
#
#print sorted(getAllNames())

#aTag = Tag.getTagFor('news')
#print "tag = "+aTag.name
#print "owner = "+aTag.owner.nickname
#print "key = ", aTag.key()
#
#print "-------------"
#
#refs = BookmarkTag.all().filter('tag = ',
#    Tag.getTagFor(u'news')).fetch(1000)
#
#for ref in refs:
#  if (ref.bookmark != None):
#    print ref.bookmark.description, " ",\
#    ref.bookmark.locator
#  else:
#    print ref.bookmark

# print "-------------"

# print Bookmark.get_by_id(34), Owner.getCurrent())

print "-------------"

#refs = BookmarkTag.all().filter('tag = ',
#    Tag.getTagFor(u'tech')).fetch(1000)
#
#for ref in refs:
#  print ref.bookmark.description
#
#print db.TransactionFailedError()

# owner = memcache.get(
#     "User.email="+users.get_current_user().email())
# 
# print owner.nickname
#print Owner.getCurrent().key().app()

response = fetch(
  "http://is.gd/api.php?longurl=http%3A%2F%2Feugeneciurana.com%2Fsite.php%3Fpage%3Dmusings",
  follow_redirects=False)

print type(response)
print response.status_code
print "URL = "+response.content


