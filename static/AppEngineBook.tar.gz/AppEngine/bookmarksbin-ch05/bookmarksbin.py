#!/usr/bin/env python


import os
import wsgiref.handlers

from datetime import date
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp.util \
    import run_wsgi_app

from apptools import AppHandler

from userpreferences import UserPreferences


class Bookmark:
  timeStamp   = None
  icon        = None
  description = None
  url         = None
  title       = None

  def __init__(
      self, timeStamp, icon, description, url, title):
    self.timeStamp   = timeStamp
    self.icon        = icon
    self.description = description
    self.url         = url
    self.title       = title

bookmarks = [
  Bookmark(
      date.today(), 'icon', 'Search engine',
      'http://www.google.com', 'Google'),
  Bookmark(
      date.today(), 'icon', 'Cool reads',
      'http://www.reddit.com', 'Reddit')
]


class BookmarksBin(AppHandler):
  # *** Private members ***
  def __setUserPreferences(self):
    self.response.out.write("<h2>PREFS!</h2>\n")

  def __displayBookmarksPage(self):
    x = {
        'bookmarks' : bookmarks,
        'bIsAdmin'  : self.hasAdminUser(),
        'logOffURL' : self.getLogOffURL() }
    self.renderPage('bookmarksbin.html', x)

  # *** Public methods ***

  def get(self):
    if self.hasValidUser():
      self.__displayBookmarksPage()


def main():
  application = webapp.WSGIApplication(
      [('/', BookmarksBin)], debug=True)
  run_wsgi_app(application)


if __name__ == '__main__':
  main()

