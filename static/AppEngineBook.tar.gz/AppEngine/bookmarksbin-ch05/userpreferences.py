


from google.appengine.ext import db


class UserPreferences(db.Model):
  userName    = db.StringProperty()
  userAccount = db.UserProperty(required=True)
  bSortByDate = db.BooleanProperty()


