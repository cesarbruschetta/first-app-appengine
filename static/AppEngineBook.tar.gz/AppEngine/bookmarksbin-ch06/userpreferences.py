


import cgi

from google.appengine.api import users
from google.appengine.ext import db

from apptools import AppHandler

from owner import Owner


class UserPreferences(AppHandler):
  # *** Private members ***

  def _initDefaultFormValues(self):
    user = users.get_current_user()
    
    return dict(
        nickname = user.nickname(),
        email    = user.email(),
        bOpenNew = True)


  def _initCurrentFormValues(self):
    query = Owner.gql("WHERE user = :1",
        users.get_current_user())

    owner = query.get()

    return dict(
        nickname = owner.nickname,
        email    = owner.email,
        bOpenNew = owner.bOpenNew)


  def _updateOwnerPreferences(self):
    if (self.request.get('bNewUser') == "True"):
      owner = Owner(
        bOpenNew = self.request.get('bOpenNew') == "True",
        user     = users.get_current_user(),
        email    = cgi.escape(self.request.get('email')),
        nickname = cgi.escape(
            self.request.get('nickname')))
    else:
      query = Owner.gql("WHERE user = :1",
          users.get_current_user())

      owner = query.get()

      owner.email = cgi.escape(self.request.get('email'))
      owner.bOpenNew = self.request.get(
            'bOpenNew'
          ) == "True"
      owner.nickname = cgi.escape(
          self.request.get('nickname'))
      
    owner.put()


  def _displayUserPreferencesPage(self):
    if (self.isNewUser()):
      v = self._initDefaultFormValues()
      v['bNewUser'] = True
    else:
      v = self._initCurrentFormValues()
      v['bNewUser'] = False

    v['logOffURL'] = self.getLogOffURL()
    self.renderPage('userpreferences.html', v)


  # *** Public methods ***

  def get(self):
    if self.hasValidUser():
      self._displayUserPreferencesPage()

  
  def post(self):
    if self.hasValidUser():
      self._updateOwnerPreferences()
      self._displayUserPreferencesPage()

