


from google.appengine.ext import db

from owner import Owner


class Bookmark(db.Model):
  description = db.StringProperty()
  favIcon     = db.LinkProperty()
  locator     = db.LinkProperty()
  timeStamp   = db.DateTimeProperty(auto_now_add = True)
  title       = db.StringProperty()
  owner       = db.ReferenceProperty(Owner,
      collection_name = 'bookmarks')


  @classmethod
  def getAll(self):
    return Bookmark.all().filter('owner = ',
        Owner.getCurrent()).order(
        'description').fetch(1000)


  @property
  def dateTimeText(self):
    return self.timeStamp.strftime("%Y.%m.%d")


  @property
  def id_or_name(self):
    return self.key().id_or_name()

