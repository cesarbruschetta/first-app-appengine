


from google.appengine.ext import db

from owner import Owner


class Tag(db.Model):
  name = db.StringProperty()
  owner = db.ReferenceProperty(Owner,
      collection_name = 'tags')


  @classmethod
  def getTagFor(self, aName):
    return self.all().filter('owner = ',
        Owner.getCurrent()).filter('name = ', aName).get()

  @classmethod
  def getAllNames(self):
    tags = Owner.getCurrent().tags
    tagNames = ['unclassified']

    for tag in tags:
      tagNames.append(tag.name)

    return sorted(tagNames)

