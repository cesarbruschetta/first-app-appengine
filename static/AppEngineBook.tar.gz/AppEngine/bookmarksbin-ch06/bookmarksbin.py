#!/usr/bin/env python


import cgi
import operator
import os
import wsgiref.handlers

from datetime import date
from google.appengine.ext import db
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp.util \
    import run_wsgi_app

from apptools import AppHandler
from bookmark import Bookmark
from bookmarktag import BookmarkTag
from owner import Owner
from tag import Tag
from tagsmanagement import TagsManagement
from userpreferences import UserPreferences


def commitBookmark(aBookmark, tagsList, theParent):
  aBookmark.put()
  for tag in tagsList:
    BookmarkTag(
        bookmark = aBookmark, tag = tag,
        parent = theParent).put()


def deleteBookmarkAndAssociations(aBookmark, references):
  for reference in references:
    reference.delete()
  aBookmark.delete()


class BookmarksBin(AppHandler):
  # *** Private members ***

  def _displayBookmarksPage(self,
      filteredBookmarks = None):
    v = dict(logOffURL = self.getLogOffURL())
    v['tagNames']  = Tag.getAllNames()
    t = self.request.get('tags')
    if t != '' and t != u'unclassified':
      v['currentTag'] = Tag.getTagFor(
          self.request.get('tags')).name
    if filteredBookmarks is None:
      v['bookmarks'] = Bookmark.getAll()
    else:
      v['bookmarks'] = filteredBookmarks
    v['bOpenNew'] = Owner.getCurrent().bOpenNew
    self.renderPage('bookmarksbin.html', v)


  def _addBookmark(self):
    tagNames = self.request.get_all('tags')
    bookmark = Bookmark(
       parent = Owner.getCurrent(),
       description = cgi.escape(
           self.request.get('description')),
       favIcon = None,
       locator = cgi.escape(self.request.get('locator')),
       title = None,
       owner = Owner.getCurrent())

    tagsList = list()
    if len(tagNames) < 1:
      tagsList.append(None)
    else:
      for tagName in tagNames:
        tagsList.append(Tag.getTagFor(tagName))

    db.run_in_transaction(
        commitBookmark, bookmark,
        tagsList, Owner.getCurrent())


  def _deleteBookmark(self):
    nID = int(self.request.get('bookmarkID'))
    bookmark = Bookmark.get_by_id(nID, Owner.getCurrent())
    references = BookmarkTag.all().filter(
        'bookmark = ', bookmark).fetch(1000)

    db.run_in_transaction(
        deleteBookmarkAndAssociations,
        bookmark, references)

    return None


  def _filterBookmarksFor(self, tag):
    if (tag == u'unclassified'):
      bookmarks = Bookmark.getAll()
    else:
      bookmarks = [x.bookmark 
          for x in BookmarkTag.all().filter(
            'tag = ', Tag.getTagFor(tag)).fetch(1000)]
      bookmarks.sort(
          key=operator.attrgetter('description'))

    return bookmarks


  def _processAction(self):
    action = self.request.get('action')

    bookmarks = Bookmark.getAll()

    if action == 'add':
      self._addBookmark()
      bookmarks = Bookmark.getAll()
    elif action == 'view':
      bookmarks = self._filterBookmarksFor(
          self.request.get('tags'))
    elif action == 'del':
      bookmarks = self._deleteBookmark()

    return bookmarks


  # *** Public methods ***

  def get(self):
    if self.hasValidUser():
      if self.isNewUser():
        self.redirect("/userpreferences")
      else:
        self._displayBookmarksPage()


  def post(self):
    if self.hasValidUser():
      if self.isNewUser():
        self.redirect("/userpreferences")
      else:
        bookmarks = self._processAction()
        self._displayBookmarksPage(bookmarks)


def main():
  application = webapp.WSGIApplication([
      ('/', BookmarksBin),
      ('/userpreferences', UserPreferences),
      ('/tagsmanagement', TagsManagement)],
      debug=True)
  run_wsgi_app(application)


if __name__ == '__main__':
  main()

